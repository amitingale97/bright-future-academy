import { useState, useEffect, useRef } from 'react';
import {
  Menu, X, Phone, Mail, MapPin, Clock, ChevronDown, ChevronUp,
  GraduationCap, Users, Award, Calendar, BookOpen, CheckCircle,
  Star, ArrowRight, Quote, MessageCircle, ChevronLeft, ChevronRight,
  Facebook, Twitter, Linkedin, Instagram, Youtube, ArrowUp,
  Send, User, BookMarked, Target, Lightbulb, BarChart3, FileText, ClipboardCheck
} from 'lucide-react';

// Animated Counter Hook
function useCountUp(end: number, duration: number = 2000, startOnView: boolean = true) {
  const [count, setCount] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!startOnView) {
      animateCount();
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasStarted) {
          setHasStarted(true);
          animateCount();
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [end, duration, hasStarted, startOnView]);

  const animateCount = () => {
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };
    requestAnimationFrame(step);
  };

  return { count, ref };
}

// Intersection Observer Hook for animations
function useInView(threshold: number = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [threshold]);

  return { ref, isInView };
}

// Navigation Component
function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Courses', href: '#courses' },
    { name: 'Faculty', href: '#faculty' },
    { name: 'Results', href: '#results' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-lg' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <a href="#home" className="flex items-center gap-3">
            <div className={`p-2 rounded-xl transition-all duration-300 ${
              isScrolled ? 'bg-primary-600' : 'bg-white/20 backdrop-blur'
            }`}>
              <GraduationCap className={`w-8 h-8 ${isScrolled ? 'text-white' : 'text-white'}`} />
            </div>
            <div>
              <span className={`font-heading font-bold text-xl transition-colors duration-300 ${
                isScrolled ? 'text-primary-800' : 'text-white'
              }`}>Bright Future</span>
              <span className={`block text-xs font-medium transition-colors duration-300 ${
                isScrolled ? 'text-primary-600' : 'text-white/80'
              }`}>Academy</span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`nav-link transition-colors duration-300 ${
                  isScrolled ? 'text-secondary-700' : 'text-white/90 hover:text-white'
                }`}
              >
                {link.name}
              </a>
            ))}
            <button className="btn-primary">
              Enroll Now
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className={`lg:hidden p-2 rounded-lg transition-colors duration-300 ${
              isScrolled ? 'text-secondary-700' : 'text-white'
            }`}
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 bg-white shadow-xl rounded-b-2xl py-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block px-6 py-3 text-secondary-700 hover:bg-primary-50 hover:text-primary-600 transition-colors"
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <div className="px-4 pt-2">
              <button className="btn-primary w-full">Enroll Now</button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

// Hero Section
function HeroSection() {
  const stats1 = useCountUp(5000);
  const stats2 = useCountUp(95);
  const stats3 = useCountUp(100);
  const stats4 = useCountUp(10);

  return (
    <section id="home" className="relative min-h-screen flex items-center hero-gradient overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      {/* Floating Elements */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-white/5 rounded-full blur-3xl animate-pulse-slow" />
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-primary-400/10 rounded-full blur-3xl animate-pulse-slow" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6 animate-fade-in">
              <Award className="w-5 h-5 text-accent-400" />
              <span className="text-white/90 text-sm font-medium">Rated #1 Coaching Institute in Pune</span>
            </div>

            <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-6 leading-tight animate-fade-in-up">
              Shape Your Future with
              <span className="block text-accent-400 mt-2">Bright Future Academy</span>
            </h1>

            <p className="text-lg sm:text-xl text-white/80 mb-8 max-w-2xl mx-auto lg:mx-0 animate-fade-in-up stagger-2">
              Expert Coaching for JEE, NEET, MHT-CET, Board Exams and Competitive Exams.
              Your success story begins here.
            </p>

            <div className="flex flex-wrap justify-center lg:justify-start gap-4 mb-12 animate-fade-in-up stagger-3">
              <button className="btn-primary bg-accent-500 hover:bg-accent-600 text-secondary-900">
                <BookOpen className="w-5 h-5" />
                Enroll Now
              </button>
              <button className="btn-secondary border-white text-white hover:bg-white/10">
                <Phone className="w-5 h-5" />
                Contact Us
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-fade-in-up stagger-4">
              <div ref={stats1.ref} className="text-center p-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20">
                <div className="text-3xl sm:text-4xl font-bold text-white">{stats1.count}+</div>
                <div className="text-white/70 text-sm">Students Trained</div>
              </div>
              <div ref={stats2.ref} className="text-center p-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20">
                <div className="text-3xl sm:text-4xl font-bold text-white">{stats2.count}%</div>
                <div className="text-white/70 text-sm">Success Rate</div>
              </div>
              <div ref={stats3.ref} className="text-center p-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20">
                <div className="text-3xl sm:text-4xl font-bold text-white">{stats3.count}+</div>
                <div className="text-white/70 text-sm">Top Rankers</div>
              </div>
              <div ref={stats4.ref} className="text-center p-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20">
                <div className="text-3xl sm:text-4xl font-bold text-white">{stats4.count}+</div>
                <div className="text-white/70 text-sm">Years Experience</div>
              </div>
            </div>
          </div>

          {/* Hero Image/Illustration */}
          <div className="hidden lg:block relative animate-fade-in">
            <div className="relative w-full aspect-square max-w-lg mx-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-3xl" />
              <img
                src="https://images.pexels.com/photos/5212348/pexels-photo-5212348.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Students studying"
                className="w-full h-full object-cover rounded-3xl shadow-2xl"
              />
              {/* Floating Cards */}
              <div className="absolute -left-8 top-1/4 bg-white rounded-xl shadow-xl p-4 animate-bounce-slow">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-secondary-800">JEE Advanced</div>
                    <div className="text-xs text-secondary-500">AIR 523</div>
                  </div>
                </div>
              </div>
              <div className="absolute -right-4 bottom-1/4 bg-white rounded-xl shadow-xl p-4 animate-bounce-slow" style={{ animationDelay: '0.5s' }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                    <Award className="w-5 h-5 text-primary-600" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-secondary-800">NEET 2024</div>
                    <div className="text-xs text-secondary-500">690/720 Score</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce-slow">
        <a href="#about" className="text-white/60 hover:text-white transition-colors">
          <ChevronDown className="w-8 h-8" />
        </a>
      </div>
    </section>
  );
}

// About Section
function AboutSection() {
  const { ref, isInView } = useInView();

  return (
    <section id="about" className="py-20 lg:py-32 bg-secondary-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          ref={ref}
          className={`grid lg:grid-cols-2 gap-12 lg:gap-16 items-center transition-all duration-700 ${
            isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          }`}
        >
          {/* Image Side */}
          <div className="relative">
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/4144956/pexels-photo-4144956.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Teaching session"
                className="rounded-2xl shadow-2xl w-full object-cover aspect-[4/3]"
              />
              {/* Stats overlay */}
              <div className="absolute -bottom-6 -right-6 bg-primary-600 rounded-2xl p-6 shadow-xl">
                <div className="text-center">
                  <div className="text-4xl font-bold text-white">15+</div>
                  <div className="text-primary-100 text-sm">Years of Excellence</div>
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -z-10 -top-4 -left-4 w-full h-full bg-primary-200 rounded-2xl" />
          </div>

          {/* Content Side */}
          <div>
            <div className="inline-flex items-center gap-2 bg-primary-100 px-4 py-2 rounded-full mb-6">
              <GraduationCap className="w-5 h-5 text-primary-600" />
              <span className="text-primary-700 font-medium text-sm">About Us</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-secondary-900 mb-6">
              About Bright Future Academy
            </h2>

            <p className="text-lg text-secondary-600 mb-8 leading-relaxed">
              Bright Future Academy is dedicated to helping students achieve academic excellence
              through expert guidance, structured learning, and personalized mentorship. Our experienced
              faculty members focus on building strong concepts, improving problem-solving skills, and
              preparing students for competitive examinations.
            </p>

            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {[
                { icon: Users, text: 'Expert Faculty Team' },
                { icon: BookOpen, text: 'Comprehensive Study Material' },
                { icon: Target, text: 'Result-Oriented Approach' },
                { icon: Lightbulb, text: 'Innovative Teaching Methods' },
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary-100 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-primary-600" />
                  </div>
                  <span className="text-secondary-700 font-medium">{item.text}</span>
                </div>
              ))}
            </div>

            <button className="btn-primary">
              Learn More About Us
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

// Courses Section
function CoursesSection() {
  const { ref, isInView } = useInView();

  const courses = [
    {
      title: 'JEE Preparation',
      description: 'Complete Physics, Chemistry and Mathematics coaching with rigorous practice.',
      icon: BookOpen,
      image: 'https://images.pexels.com/photos/4144956/pexels-photo-4144956.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'primary',
    },
    {
      title: 'NEET Preparation',
      description: 'Comprehensive Biology, Physics and Chemistry preparation for medical aspirants.',
      icon: HeartIcon,
      image: 'https://images.pexels.com/photos/5212324/pexels-photo-5212324.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'accent',
    },
    {
      title: 'MHT-CET',
      description: 'Targeted preparation with regular mock tests for Maharashtra CET.',
      icon: Target,
      image: 'https://images.pexels.com/photos/5428999/pexels-photo-5428999.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'primary',
    },
    {
      title: 'Board Exam Coaching',
      description: 'Specialized classes for 10th and 12th board students.',
      icon: BookMarked,
      image: 'https://images.pexels.com/photos/5212348/pexels-photo-5212348.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'accent',
    },
    {
      title: 'Foundation Courses',
      description: 'Early preparation for competitive exams from class 8th onwards.',
      icon: GraduationCap,
      image: 'https://images.pexels.com/photos/4144956/pexels-photo-4144956.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'primary',
    },
    {
      title: 'Scholarship Preparation',
      description: 'Guidance for various scholarship examinations like NTSE, Olympiads.',
      icon: Award,
      image: 'https://images.pexels.com/photos/5212324/pexels-photo-5212324.jpeg?auto=compress&cs=tinysrgb&w=400',
      color: 'accent',
    },
  ];

  return (
    <section id="courses" className="py-20 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary-100 px-4 py-2 rounded-full mb-6">
            <BookOpen className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium text-sm">Our Programs</span>
          </div>
          <h2 className="section-title">Courses We Offer</h2>
          <p className="section-subtitle">
            Comprehensive coaching programs designed to help students excel in their academic journey
          </p>
        </div>

        <div
          ref={ref}
          className={`grid md:grid-cols-2 lg:grid-cols-3 gap-8 transition-all duration-700 ${
            isInView ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {courses.map((course, idx) => (
            <div
              key={idx}
              className={`card card-hover card-shine group stagger-${idx + 1}`}
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    course.color === 'primary' ? 'bg-primary-600' : 'bg-accent-500'
                  }`}>
                    <course.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-secondary-900 mb-2">{course.title}</h3>
                <p className="text-secondary-600 mb-4">{course.description}</p>
                <button className="inline-flex items-center text-primary-600 font-semibold hover:text-primary-700 transition-colors group/btn">
                  Learn More
                  <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover/btn:translate-x-1" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Custom Heart Icon for NEET
function HeartIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
    </svg>
  );
}

// Why Choose Us Section
function WhyChooseSection() {
  const { ref, isInView } = useInView();

  const features = [
    { icon: Users, title: 'Experienced Faculty', description: 'Learn from IIT & NEET toppers with 10+ years experience' },
    { icon: BookOpen, title: 'Small Batch Sizes', description: 'Focused attention with limited students per batch' },
    { icon: ClipboardCheck, title: 'Regular Mock Tests', description: 'Weekly tests to track progress and improve performance' },
    { icon: MessageCircle, title: 'Doubt Solving', description: 'Dedicated doubt-clearing sessions with faculty' },
    { icon: User, title: 'Personalized Attention', description: 'Individual mentoring for each student' },
    { icon: BarChart3, title: 'Performance Tracking', description: 'Regular analysis and feedback on performance' },
    { icon: FileText, title: 'Study Material', description: 'Comprehensive and updated study materials' },
    { icon: ClipboardCheck, title: 'Parent Reports', description: 'Regular parent-teacher meetings and progress reports' },
  ];

  return (
    <section id="why-us" className="py-20 lg:py-32 bg-gradient-to-br from-primary-800 to-primary-900 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full mb-6">
            <Star className="w-5 h-5 text-accent-400" />
            <span className="text-white/90 font-medium text-sm">Why Choose Us</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            What Makes Us Different
          </h2>
          <p className="text-lg text-white/70 max-w-2xl mx-auto">
            Our unique teaching methodology and student-centric approach sets us apart
          </p>
        </div>

        <div
          ref={ref}
          className={`grid sm:grid-cols-2 lg:grid-cols-4 gap-6 transition-all duration-700 ${
            isInView ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {features.map((feature, idx) => (
            <div
              key={idx}
              className={`group bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 hover:-translate-y-2 stagger-${idx + 1}`}
            >
              <div className="w-14 h-14 rounded-xl bg-primary-600/50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <feature.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-white/70 text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Faculty Section
function FacultySection() {
  const { ref, isInView } = useInView();

  const faculty = [
    {
      name: 'Dr. Rajesh Sharma',
      role: 'Director & Physics Expert',
      experience: '15+ Years Experience',
      image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      name: 'Prof. Anjali Verma',
      role: 'Biology Specialist',
      experience: '12+ Years Experience',
      image: 'https://images.pexels.com/photos/3764390/pexels-photo-3764390.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      name: 'Prof. Amit Kulkarni',
      role: 'Mathematics Expert',
      experience: '10+ Years Experience',
      image: 'https://images.pexels.com/photos/3777930/pexels-photo-3777930.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      name: 'Prof. Sneha Patil',
      role: 'Chemistry Faculty',
      experience: '11+ Years Experience',
      image: 'https://images.pexels.com/photos/3764390/pexels-photo-3764390.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  return (
    <section id="faculty" className="py-20 lg:py-32 bg-secondary-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary-100 px-4 py-2 rounded-full mb-6">
            <Users className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium text-sm">Our Team</span>
          </div>
          <h2 className="section-title">Meet Our Expert Faculty</h2>
          <p className="section-subtitle">
            Learn from the best educators with proven track records in competitive exam preparation
          </p>
        </div>

        <div
          ref={ref}
          className={`grid sm:grid-cols-2 lg:grid-cols-4 gap-8 transition-all duration-700 ${
            isInView ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {faculty.map((member, idx) => (
            <div
              key={idx}
              className={`card card-hover text-center stagger-${idx + 1}`}
            >
              <div className="relative overflow-hidden">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full aspect-square object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary-900/80 to-transparent opacity-0 hover:opacity-100 transition-opacity flex items-end justify-center pb-6">
                  <div className="flex gap-4">
                    <a href="#" className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
                      <Linkedin className="w-5 h-5 text-white" />
                    </a>
                    <a href="#" className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
                      <Mail className="w-5 h-5 text-white" />
                    </a>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-secondary-900">{member.name}</h3>
                <p className="text-primary-600 font-medium mb-2">{member.role}</p>
                <p className="text-secondary-500 text-sm flex items-center justify-center gap-2">
                  <Clock className="w-4 h-4" />
                  {member.experience}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Results Section
function ResultsSection() {
  const { ref, isInView } = useInView();

  const achievers = [
    { name: 'Aarav Sharma', achievement: 'JEE AIR 523', image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Priya Patil', achievement: 'NEET Score 690/720', image: 'https://images.pexels.com/photos/3764390/pexels-photo-3764390.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Rohan Deshmukh', achievement: 'MHT-CET 99.4%', image: 'https://images.pexels.com/photos/3777930/pexels-photo-3777930.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'Sneha Gupta', achievement: 'Board Exam 96%', image: 'https://images.pexels.com/photos/3764390/pexels-photo-3764390.jpeg?auto=compress&cs=tinysrgb&w=400' },
  ];

  return (
    <section id="results" className="py-20 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-accent-100 px-4 py-2 rounded-full mb-6">
            <Award className="w-5 h-5 text-accent-600" />
            <span className="text-accent-700 font-medium text-sm">Success Stories</span>
          </div>
          <h2 className="section-title">Student Results</h2>
          <p className="section-subtitle">
            Our students consistently achieve top ranks in competitive examinations
          </p>
        </div>

        <div
          ref={ref}
          className={`grid sm:grid-cols-2 lg:grid-cols-4 gap-8 transition-all duration-700 ${
            isInView ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {achievers.map((student, idx) => (
            <div
              key={idx}
              className={`card card-hover text-center stagger-${idx + 1}`}
            >
              <div className="relative">
                <img
                  src={student.image}
                  alt={student.name}
                  className="w-32 h-32 mx-auto rounded-full object-cover mt-6 border-4 border-primary-100"
                />
                <div className="absolute top-4 right-4">
                  <div className="w-8 h-8 rounded-full bg-accent-500 flex items-center justify-center">
                    <Star className="w-4 h-4 text-white" />
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-lg font-bold text-secondary-900">{student.name}</h3>
                <div className="inline-flex items-center gap-2 bg-primary-50 px-4 py-2 rounded-full mt-2">
                  <Award className="w-4 h-4 text-primary-600" />
                  <span className="text-primary-700 font-semibold text-sm">{student.achievement}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats Banner */}
        <div className="mt-16 bg-gradient-to-r from-primary-600 to-primary-800 rounded-3xl p-8 lg:p-12">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">500+</div>
              <div className="text-white/70">JEE Selections</div>
            </div>
            <div>
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">800+</div>
              <div className="text-white/70">NEET Selections</div>
            </div>
            <div>
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">1200+</div>
              <div className="text-white/70">MHT-CET Selections</div>
            </div>
            <div>
              <div className="text-4xl lg:text-5xl font-bold text-white mb-2">95%</div>
              <div className="text-white/70">Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Testimonials Section
function TestimonialsSection() {
  const [current, setCurrent] = useState(0);

  const testimonials = [
    { text: 'The faculty support and mock tests helped me secure a top rank in NEET. The personalized attention made all the difference.', name: 'Priya Patil', achievement: 'NEET 2023 - 690/720' },
    { text: 'Excellent teaching methods and personal attention. The faculty truly cares about each student\'s success.', name: 'Aarav Sharma', achievement: 'JEE Advanced - AIR 523' },
    { text: 'The best coaching institute for competitive exams. The study material and test series are top-notch.', name: 'Rohan Deshmukh', achievement: 'MHT-CET - 99.4 Percentile' },
  ];

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <section className="py-20 lg:py-32 bg-secondary-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary-100 px-4 py-2 rounded-full mb-6">
            <Quote className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium text-sm">Testimonials</span>
          </div>
          <h2 className="section-title">What Our Students Say</h2>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-8 lg:p-12 text-center">
            <Quote className="w-12 h-12 text-primary-200 mx-auto mb-6" />
            <p className="text-xl lg:text-2xl text-secondary-700 mb-8 leading-relaxed">
              "{testimonials[current].text}"
            </p>
            <div>
              <div className="w-16 h-16 bg-gradient-to-br from-primary-500 to-primary-700 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl">
                {testimonials[current].name.charAt(0)}
              </div>
              <h4 className="font-bold text-secondary-900">{testimonials[current].name}</h4>
              <p className="text-primary-600 font-medium">{testimonials[current].achievement}</p>
            </div>
          </div>

          {/* Navigation */}
          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 lg:-translate-x-6 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center hover:bg-primary-50 transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-secondary-700" />
          </button>
          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 lg:translate-x-6 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center hover:bg-primary-50 transition-colors"
          >
            <ChevronRight className="w-6 h-6 text-secondary-700" />
          </button>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrent(idx)}
                className={`w-3 h-3 rounded-full transition-all ${
                  current === idx ? 'bg-primary-600 w-8' : 'bg-secondary-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Gallery Section
function GallerySection() {
  const { ref, isInView } = useInView();

  const images = [
    { src: 'https://images.pexels.com/photos/5212348/pexels-photo-5212348.jpeg?auto=compress&cs=tinysrgb&w=600', title: 'Classroom Sessions' },
    { src: 'https://images.pexels.com/photos/4144956/pexels-photo-4144956.jpeg?auto=compress&cs=tinysrgb&w=600', title: 'Seminar Sessions' },
    { src: 'https://images.pexels.com/photos/5428999/pexels-photo-5428999.jpeg?auto=compress&cs=tinysrgb&w=600', title: 'Award Ceremonies' },
    { src: 'https://images.pexels.com/photos/5212324/pexels-photo-5212324.jpeg?auto=compress&cs=tinysrgb&w=600', title: 'Student Activities' },
    { src: 'https://images.pexels.com/photos/4144956/pexels-photo-4144956.jpeg?auto=compress&cs=tinysrgb&w=600', title: 'Lab Sessions' },
    { src: 'https://images.pexels.com/photos/5212348/pexels-photo-5212348.jpeg?auto=compress&cs=tinysrgb&w=600', title: 'Study Groups' },
  ];

  return (
    <section id="gallery" className="py-20 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary-100 px-4 py-2 rounded-full mb-6">
            <Calendar className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium text-sm">Gallery</span>
          </div>
          <h2 className="section-title">Our Campus Life</h2>
          <p className="section-subtitle">
            A glimpse into the vibrant learning environment at Bright Future Academy
          </p>
        </div>

        <div
          ref={ref}
          className={`grid grid-cols-2 md:grid-cols-3 gap-4 transition-all duration-700 ${
            isInView ? 'opacity-100' : 'opacity-0'
          }`}
        >
          {images.map((img, idx) => (
            <div
              key={idx}
              className={`gallery-item rounded-xl overflow-hidden aspect-square stagger-${idx + 1}`}
            >
              <img src={img.src} alt={img.title} className="w-full h-full object-cover" />
              <div className="gallery-overlay flex items-end p-4">
                <span className="text-white font-semibold">{img.title}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// FAQ Section
function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: 'What courses do you offer?',
      answer: 'We offer comprehensive coaching for JEE, NEET, MHT-CET, Board Exams (10th & 12th), Foundation Courses, and Scholarship Exam Preparation. Each course is designed with expert faculty guidance and comprehensive study materials.',
    },
    {
      question: 'Do you provide study material?',
      answer: 'Yes, we provide comprehensive, regularly updated study materials prepared by our expert faculty. The materials include detailed notes, practice problems, previous year questions, and topic-wise summaries.',
    },
    {
      question: 'Are online classes available?',
      answer: 'Yes, we offer both offline and online classes. Our online platform includes live interactive sessions, recorded lectures, online tests, and doubt-clearing sessions.',
    },
    {
      question: 'How are mock tests conducted?',
      answer: 'We conduct regular weekly and full-syllabus mock tests in an exam-like environment. Tests are followed by detailed analysis and discussion sessions to help students improve their performance.',
    },
    {
      question: 'What are the batch timings?',
      answer: 'We offer flexible batch timings including morning batches (6 AM - 10 AM), afternoon batches (2 PM - 6 PM), and evening batches (5 PM - 9 PM). Weekend batches are also available.',
    },
  ];

  return (
    <section className="py-20 lg:py-32 bg-secondary-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary-100 px-4 py-2 rounded-full mb-6">
            <MessageCircle className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium text-sm">FAQs</span>
          </div>
          <h2 className="section-title">Frequently Asked Questions</h2>
          <p className="section-subtitle">
            Find answers to common questions about our courses and services
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="bg-white rounded-xl shadow-sm border border-secondary-200 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-secondary-50 transition-colors"
              >
                <span className="font-semibold text-secondary-900">{faq.question}</span>
                {openIndex === idx ? (
                  <ChevronUp className="w-5 h-5 text-primary-600" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-secondary-500" />
                )}
              </button>
              {openIndex === idx && (
                <div className="px-6 pb-6 text-secondary-600 leading-relaxed">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Contact Section
function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <section id="contact" className="py-20 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-primary-100 px-4 py-2 rounded-full mb-6">
            <Phone className="w-5 h-5 text-primary-600" />
            <span className="text-primary-700 font-medium text-sm">Contact Us</span>
          </div>
          <h2 className="section-title">Get In Touch</h2>
          <p className="section-subtitle">
            Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-secondary-50 rounded-2xl p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-secondary-700 font-medium mb-2">Full Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border border-secondary-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                  placeholder="Enter your name"
                />
              </div>
              <div>
                <label className="block text-secondary-700 font-medium mb-2">Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border border-secondary-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                  placeholder="Enter your email"
                />
              </div>
              <div>
                <label className="block text-secondary-700 font-medium mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg border border-secondary-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
                  placeholder="Enter your phone number"
                />
              </div>
              <div>
                <label className="block text-secondary-700 font-medium mb-2">Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg border border-secondary-300 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all resize-none"
                  placeholder="How can we help you?"
                />
              </div>
              <button type="submit" className="btn-primary w-full">
                <Send className="w-5 h-5" />
                Send Message
              </button>
            </form>
          </div>

          {/* Contact Info & Map */}
          <div className="space-y-8">
            {/* Contact Details */}
            <div className="bg-gradient-to-br from-primary-600 to-primary-800 rounded-2xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-6">Contact Information</h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-semibold">Address</p>
                    <p className="text-white/80">123 Education Street, Pune, Maharashtra</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-semibold">Phone</p>
                    <p className="text-white/80">+91 98765 43210</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-semibold">Email</p>
                    <p className="text-white/80">info@brightfutureacademy.com</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-semibold">Office Hours</p>
                    <p className="text-white/80">Mon - Sat: 9:00 AM - 8:00 PM</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Map */}
            <div className="bg-secondary-100 rounded-2xl overflow-hidden h-64">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3780.846244393!2d73.8567!3d18.5204!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTjCsDMxJzEzLjQiTiA3M8KwNTEnMjQuMSJF!5e0!3m2!1sen!2sin!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Bright Future Academy Location"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  return (
    <footer className="bg-secondary-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-primary-600">
                <GraduationCap className="w-8 h-8 text-white" />
              </div>
              <div>
                <span className="font-heading font-bold text-xl">Bright Future</span>
                <span className="block text-xs text-secondary-400">Academy</span>
              </div>
            </div>
            <p className="text-secondary-400 text-sm leading-relaxed">
              Shaping the future of students through quality education and expert guidance since 2014.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Instagram, Linkedin, Youtube].map((Icon, idx) => (
                <a
                  key={idx}
                  href="#"
                  className="w-10 h-10 rounded-lg bg-secondary-800 flex items-center justify-center hover:bg-primary-600 transition-colors"
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {['Home', 'About Us', 'Courses', 'Results', 'Gallery', 'Contact'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(' ', '')}`} className="text-secondary-400 hover:text-white transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Courses</h4>
            <ul className="space-y-3">
              {['JEE Preparation', 'NEET Preparation', 'MHT-CET', 'Board Exams', 'Foundation Courses', 'Scholarship Exams'].map((course) => (
                <li key={course}>
                  <a href="#courses" className="text-secondary-400 hover:text-white transition-colors">
                    {course}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-primary-500 flex-shrink-0 mt-1" />
                <span className="text-secondary-400">123 Education Street, Pune, Maharashtra</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-primary-500" />
                <span className="text-secondary-400">+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-primary-500" />
                <span className="text-secondary-400">info@brightfutureacademy.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-secondary-800 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-secondary-500 text-sm">
            © 2024 Bright Future Academy. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-secondary-500 hover:text-white text-sm transition-colors">Privacy Policy</a>
            <a href="#" className="text-secondary-500 hover:text-white text-sm transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

// WhatsApp Floating Button
function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/919876543210"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-green-500 rounded-full flex items-center justify-center shadow-lg whatsapp-pulse hover:bg-green-600 transition-colors"
    >
      <svg className="w-7 h-7 text-white" fill="currentColor" viewBox="0 0 24 24">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z" />
      </svg>
    </a>
  );
}

// Back to Top Button
function BackToTop() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      setIsVisible(window.scrollY > 500);
    };
    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      onClick={scrollToTop}
      className={`fixed bottom-6 left-6 z-50 w-12 h-12 bg-primary-600 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 hover:bg-primary-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'
      }`}
    >
      <ArrowUp className="w-5 h-5 text-white" />
    </button>
  );
}

// Main App Component
function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <CoursesSection />
      <WhyChooseSection />
      <FacultySection />
      <ResultsSection />
      <TestimonialsSection />
      <GallerySection />
      <FAQSection />
      <ContactSection />
      <Footer />
      <WhatsAppButton />
      <BackToTop />
    </div>
  );
}

export default App;
